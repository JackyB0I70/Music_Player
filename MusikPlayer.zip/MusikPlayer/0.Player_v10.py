import os
import random
import tkinter as tk
from tkinter import scrolledtext
import pygame

class MusicPlayer:
    def __init__(self, master):
        self.master = master
        self.master.title("Music Player")
        self.master.geometry("700x550")
        self.master.configure(bg='black')
        self.master.iconbitmap("0.Logo.ico")

        self.song_list = []
        self.current_song_index = 0
        self.paused = False
        self.current_song = None
        self.song_length = 0

        self.load_songs()
        self.create_widgets()
        self.update_song_timer()

    def load_songs(self):
        folder_path = os.path.join(os.path.expanduser("~"), "Documents", "Python", "MusikPlayer")
        self.song_list = [os.path.join(folder_path, f) for f in os.listdir(folder_path) if f.endswith('.mp3')]
        random.shuffle(self.song_list)

    def create_widgets(self):
        self.label_title = tk.Label(self.master, bg="black", fg='#FF0000', font="bold 25", text="MUSIC PLAYER")
        self.label_title.place(x=100, y=50, width=500, height=30)
        
        self.song_label = tk.Label(self.master, bg="black", fg='blue', font="bold 15", text="")
        self.song_label.place(x=100, y=100, width=500, height=30)

        self.song_timer_label = tk.Label(self.master, bg="black", fg='green', font="bold 10", text="")
        self.song_timer_label.place(x=100, y=150, width=500, height=20)

        self.button_play = tk.Button(self.master, text="PLAY", command=self.play)
        self.button_play.place(x=300, y=200, width=100, height=30)

        self.button_pause = tk.Button(self.master, text="PAUSE", command=self.pause)
        self.button_pause.place(x=300, y=250, width=100, height=30)

        self.button_next = tk.Button(self.master, text=">>", command=self.skip)
        self.button_next.place(x=380, y=300, width=30, height=30)

        self.previous_button = tk.Button(self.master, text="<<", command=self.previous)
        self.previous_button.place(x=290, y=300, width=30, height=30)

        self.show_songs_button = tk.Button(self.master, text="v", command=self.show_songs)
        self.show_songs_button.place(x=330, y=300, width=40, height=30)

        self.master.protocol("WM_DELETE_WINDOW", self.on_closing)

    def play(self):
        if self.paused:
            pygame.mixer.music.unpause()
            self.paused = False
        else:
            if self.song_list:
                self.current_song = self.song_list[self.current_song_index]
                pygame.mixer.music.load(self.current_song)
                pygame.mixer.music.play()
                self.song_length = pygame.mixer.Sound(self.current_song).get_length()
                self.update_song_label()

                pygame.mixer.music.set_endevent(pygame.USEREVENT)

    def pause(self):
        if pygame.mixer.music.get_busy():
            pygame.mixer.music.pause()
            self.paused = True

    def skip(self):
        if self.song_list:
            self.current_song_index = (self.current_song_index + 1) % len(self.song_list)
            self.play()

    def previous(self):
        if self.song_list:
            self.current_song_index = (self.current_song_index - 1) % len(self.song_list)
            self.play()

    def on_closing(self):
        pygame.mixer.music.stop()
        self.master.destroy()

    def update_song_label(self):
        if self.song_list:
            song_name = os.path.basename(self.current_song)
            song_name = song_name.split(".mp3")[0]
            song_name_parts = song_name.split("_")
            reordered_song_name = song_name_parts[1] + ", " + song_name_parts[0]
            self.song_label.config(text=reordered_song_name)

    def update_song_timer(self):
        if pygame.mixer.music.get_busy():
            current_time = pygame.mixer.music.get_pos() // 1000
            current_time_formatted = "{:02d}:{:02d}".format(current_time // 60, current_time % 60)
            song_length_formatted = "{:02d}:{:02d}".format(int(self.song_length) // 60, int(self.song_length) % 60)
            self.song_timer_label.config(text=f"{current_time_formatted} / {song_length_formatted}")
        else:
            self.song_timer_label.config(text="")

        self.master.after(500, self.update_song_timer)

        for event in pygame.event.get():
            if event.type == pygame.USEREVENT:
                self.skip()

    def show_songs(self):
        songs_window = tk.Toplevel(self.master)
        songs_window.title("Song List")
        songs_window.geometry("400x300")
        songs_window.configure(bg="black")
        songs_window.iconbitmap("0.Logo.ico")

        scroll_area = scrolledtext.ScrolledText(songs_window, width=40, height=20, wrap=tk.WORD, bg="black", fg="white")
        scroll_area.pack(expand=True, fill="both")

        # Change cursor to arrow when hovering over scroll_area
        scroll_area.configure(cursor="arrow")

        for i, song in enumerate(self.song_list, start=1):
            song_name = os.path.basename(song).split(".mp3")[0]
            song_name_parts = song_name.split("_")
        
            if len(song_name_parts) >= 2:
                reordered_song_name = song_name_parts[1] + ", " + song_name_parts[0]
            else:
                reordered_song_name = song_name  # Use the original name if parts are missing
            
            print("Song name:", song_name)  # Print the song name for debugging
            scroll_area.insert(tk.END, f"{i}. {reordered_song_name}\n")

            # Bind the play_song function to the song name clicked in the listbox
            scroll_area.tag_bind(f"song_{i}", "<Button-1>", lambda event, index=i: self.play_song(event, index))

            # Add a tag to the song name for binding
            scroll_area.tag_add(f"song_{i}", f"{i}.0", f"{i}.end")


    def play_song(self, event, index):
        scroll_area = event.widget
        scroll_area.tag_remove("highlight", "1.0", tk.END)
        scroll_area.tag_add("highlight", f"{index}.0", f"{index}.end")
        scroll_area.see(f"{index}.0")

        self.current_song_index = index - 1
        self.play()

def main():
    pygame.init()
    root = tk.Tk()
    app = MusicPlayer(root)
    root.mainloop()

if __name__ == "__main__":
    main()

