import pygame
import random
import time
import tkinter as tk
from tkinter import Scrollbar

def play_music(file_path):
    pygame.mixer.init()
    pygame.mixer.music.load(file_path)
    pygame.mixer.music.play()

def on_clicked_play():
    print("PLAY!")
    global start_time
    start_time = time.time()
    play_next_song()

def on_clicked_pause():
    print("PAUSE!")
    global paused_time, is_paused, timer_id, start_time
    if is_paused:
        # Unpause the song
        pygame.mixer.music.unpause()
        is_paused = False
        start_time = time.time() - (paused_time - start_time)  # Adjust start_time
        timer_id = root.after(int((current_song.duration - (paused_time - start_time)) * 1000), play_next_song)  # Restart the timer
        update_timer_label()  # Update the timer label
    else:
        # Pause the song
        paused_time = time.time()  # Record the time when paused
        root.after_cancel(timer_id)  # Stop the timer responsible for updating the label
        pygame.mixer.music.pause()  # Pause the music
        is_paused = True
        update_timer_label()  # Update the timer label when paused



def on_clicked_next():
    global start_time, timer_id, paused_time, is_paused, current_song_index
    print("NEXT!")
    if timer_id is not None:
        root.after_cancel(timer_id)  # Cancel the current timer
    start_time = None  # Reset the start time
    paused_time = 0  # Reset paused time
    is_paused = False  # Reset paused state
    pygame.mixer.music.stop()
    current_song_index += 1  # Increment the current song index
    play_next_song()


# Create Song List Window
def Create_ListW():
    print ("List")
    # Create the listbox window
    list_window = tk.Toplevel(root)
    list_window.title("SONG LIST")
    list_window.geometry("400x300")
    list_window.iconbitmap("0.Logo.ico")
    list_window.configure(bg="black")
    # Get the current screen location of the music player window
    player_x = root.winfo_x()
    player_y = root.winfo_y()
    # Position the song list window relative to the music player window
    list_window.geometry(f"+{player_x}+{player_y}")
    # Create a scrollbar
    scrollbar = Scrollbar(list_window)
    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    # Create a listbox and attach it to the scrollbar
    listbox = tk.Listbox(list_window, yscrollcommand=scrollbar.set, bg="black", fg="white", selectbackground="#0000FF")
    listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
    scrollbar.config(command=listbox.yview)
    for i, song in enumerate(playlist, start=1):
        listbox.insert(tk.END, f"{i}. {song.title}")


def format_time(seconds):
    minutes, seconds = divmod(seconds, 60)
    return f"{int(minutes):02d}:{int(seconds):02d}"

class Song:
    def __init__(self, title, duration, song):
        self.title = title
        self.duration = duration
        self.song = song

# Create some song objects
playlist = [
    #Stellar
    Song("Bad Dream, Stellar", 148, "Stellar_BadDream.mp3"),
    Song("Grave, Stellar", 145, "Stellar_Grave.mp3"),
    Song("Stranger, Stellar", 133, "Stellar_Stranger.mp3"),
    Song("El Dorado, Stellar", 136, "Stellar_ElDorado.mp3"),
    Song("Golden Years, Stellar", 125, "Stellar_GoldenYears.mp3"),
    Song("Ashes, Stellar", 167, "Stellar_Ashes.mp3"),
    Song("Joyride, Stellar", 115, "Stellar_Joyride.mp3"),
    Song("Death Note, Stellar", 159, "Stellar_DeathNote.mp3"),
    Song("Smoking Gun, Stellar", 152, "Stellar_SmokingGun.mp3"),
    Song("Daredevil, Stellar", 136, "Stellar_Daredevil.mp3"),
    Song("Mistake, Stellar", 152, "Stellar_Mistake.mp3"),
    Song("Cold Outside, Stellar", 142, "Stellar_ColdOutside.mp3"),
    Song("More Than Friends, Stellar", 128, "Stellar_MoreThanFriends.mp3"),
    Song("No Angels, Stellar", 117, "Stellar_NoAngels.mp3")
]

# Shuffle the playlist
random.shuffle(playlist)

# Function to play each song
def play_next_song():
    global current_song_index, timer_id, is_paused, paused_time, start_time, current_song
    if current_song_index < len(playlist):
        if timer_id is not None:
            root.after_cancel(timer_id)  # Cancel any existing timer
        current_song = playlist[current_song_index]
        label_song.config(text=current_song.title)
        play_music(current_song.song)
        if is_paused:
            remaining_time = current_song.duration - (paused_time - start_time)
            timer_id = root.after(int(remaining_time * 1000), play_next_song)
        else:
            start_time = time.time()
            update_timer_label()  # Update the timer label immediately
            timer_id = root.after(1000, update_timer_label_periodically)  # Start updating the timer label periodically
            timer_id = root.after(int(current_song.duration * 1000), play_next_song)  # Schedule the next song
        is_paused = False
        current_song_index += 1


def update_timer_label_periodically():
    global current_song, start_time, is_paused, paused_time, timer_id
    if current_song is not None:
        elapsed_time = time.time() - start_time
        if hasattr(current_song, 'duration'):
            remaining_time = current_song.duration - elapsed_time
            if remaining_time <= 0:
                label_time_left.config(text="00:00")
            else:
                label_time_left.config(text=format_time(remaining_time))
            timer_id = root.after(1000, update_timer_label_periodically)
        else:
            print("Duration not found for current song")

def update_timer_label():
    global start_time, current_song
    if current_song is not None:
        elapsed_time = time.time() - start_time
        if hasattr(current_song, 'duration'):
            remaining_time = current_song.duration - elapsed_time
            if remaining_time <= 0:
                label_time_left.config(text="00:00")
            else:
                label_time_left.config(text=format_time(remaining_time))
            # Schedule the next update
            timer_id = root.after(1000, update_timer_label)
        else:
            print("Duration not found for current song")


# Create the main window
root = tk.Tk()
root.title("Musik Player")
root.geometry("700x550")
root.iconbitmap("0.Logo.ico")
root.configure(bg="black")

# Create Window Interface
label_title = tk.Label(root, bg="black", fg='#FF0000', font="bold 25", text="MUSIK PLAYER")
label_title.place(x=100, y=50, width=500, height=30)

label_song = tk.Label(root, bg="black", fg='#0000FF', font="bold 15")
label_song.place(x=100, y=100, width=500, height=30)

label_time_left = tk.Label(root, bg="black", fg='#00FF00', font="bold 10")
label_time_left.place(x=100, y=130, width=500, height=30)

button_play = tk.Button(root, text="PLAY", command=on_clicked_play)
button_play.place(x=300, y=200, width=100, height=30)

button_pause = tk.Button(root, text="PAUSE", command=on_clicked_pause)
button_pause.place(x=300, y=250, width=100, height=30)

button_next = tk.Button(root, text=">>>", command=on_clicked_next)
button_next.place(x=330, y=300, width=50, height=30)

button_list = tk.Button(root, text="LIST", command=Create_ListW)
button_list.place(x=410, y=200, width=30, height=30)

# Initialize current song index
current_song_index = 0
timer_id = None
paused_time = 0
start_time = None  # Initialize start_time as None
is_paused = False
current_song = None  # Initialize current_song as None

# Start the Tkinter event loop
root.mainloop()


