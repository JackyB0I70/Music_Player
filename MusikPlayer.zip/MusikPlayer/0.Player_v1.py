import pygame
import random
import tkinter as tk

def play_music(file_path):
    pygame.mixer.init()
    pygame.mixer.music.load(file_path)
    pygame.mixer.music.play()

def on_clicked_play():
    print("PLAY!")
    play_next_song()

def on_clicked_pause():
    print("PAUSE!")
    pygame.mixer.music.pause()

def on_clicked_next():
    print("NEXT!")
    pygame.mixer.music.stop()
    play_next_song()

class Song:
    def __init__(self, title, duration, song):
        self.title = title
        self.duration = duration
        self.song = song

# Create some song objects
playlist = [
    Song("Bad Dream, Stellar", 148, "Stellar_BadDream.mp3"),
    Song("Grave, Stellar", 145, "Stellar_Grave.mp3"),
    Song("Stranger, Stellar", 133, "Stellar_Stranger.mp3"),
    Song("El Dorado, Stellar", 136, "Stellar_ElDorado.mp3"),
    Song("Golden Years, Stellar", 125, "Stellar_GoldenYears.mp3"),
    Song("Ashes, Stellar", 167, "Stellar_Ashes.mp3"),
    Song("Joyride, Stellar", 115, "Stellar_Joyride.mp3"),
    Song("Death Note, Stellar", 159, "Stellar_DeathNote.mp3"),
    Song("Smoking Gun, Stellar", 152, "Stellar_SmokingGun.mp3"),
    Song("Daredevil, Stellar", 136, "Stellar_Daredevil.mp3"),
    Song("Mistake, Stellar", 152, "Stellar_Mistake.mp3"),
    Song("Cold Outside, Stellar", 142, "Stellar_ColdOutside.mp3"),
    Song("More Than Friends, Stellar", 128, "Stellar_MoreThanFriends.mp3"),
    Song("No Angels, Stellar", 117, "Stellar_NoAngels.mp3")
]

# Shuffle the playlist
random.shuffle(playlist)

# Function to play each song
def play_next_song():
    global current_song_index
    if current_song_index < len(playlist):
        current_song = playlist[current_song_index]
        label_song.config(text=current_song.title)
        play_music(current_song.song)
        root.after(int(current_song.duration * 1000), play_next_song)
        current_song_index += 1

# Create the main window
root = tk.Tk()
root.title("Musik Player")
root.geometry("700x550")
root.iconbitmap("0.Logo.ico")

# Create Window Interface
label_title = tk.Label(root, fg='red', font="bold 25", text="MUSIK PLAYER")
label_title.place(x=100, y=50, width=500, height=30)

label_song = tk.Label(root, fg='blue', font="bold 15")
label_song.place(x=100, y=100, width=500, height=30)

label_time_left = tk.Label(root, fg='green', font="bold 15")
label_time_left.place(x=100, y=150, width=500, height=30)

button_play = tk.Button(root, text="PLAY", command=on_clicked_play)
button_play.place(x=300, y=150, width=100, height=30)

button_pause = tk.Button(root, text="PAUSE", command=on_clicked_pause)
button_pause.place(x=300, y=200, width=100, height=30)

button_next = tk.Button(root, text=">>>", command=on_clicked_next)
button_next.place(x=330, y=250, width=50, height=30)

# Initialize current song index
current_song_index = 0

# Start the Tkinter event loop
root.mainloop()
