import os
import random
import tkinter as tk
from tkinter import ttk
import pygame
from tkinter import filedialog

class MusicPlayer:
    def __init__(self, master):
        self.master = master
        self.master.title("Musik Player")
        self.master.geometry("700x550")
        self.master.configure(bg='black')
        self.master.iconbitmap("0.Logo.ico")
        
        self.current_song_index = 0
        self.paused = False

        self.song_list = []
        self.load_songs()

        self.create_widgets()

    def load_songs(self):
        # Specify the folder path where your music files are located
        folder_path = os.path.join(os.path.expanduser("~"), "Documents", "Python", "MusikPlayer")
        self.song_list = [os.path.join(folder_path, f) for f in os.listdir(folder_path) if f.endswith('.mp3')]
        random.shuffle(self.song_list)


    def create_widgets(self):
        # Song Label
        self.label_title = tk.Label(self.master, bg="black", fg='#FF0000', font="bold 25", text="MUSIK PLAYER")
        self.label_title.place(x=100, y=50, width=500, height=30)
        
        self.song_label = tk.Label(self.master, bg="black", fg='blue', font="bold 15", text="")
        self.song_label.place(x=100, y=100, width=500, height=30)

        # Play Button
        self.button_play = tk.Button(self.master, text="PLAY", command=self.play)
        self.button_play.place(x=300, y=200, width=100, height=30)

        # Pause Button
        self.button_pause = tk.Button(self.master, text="PAUSE", command=self.pause)
        self.button_pause.place(x=300, y=250, width=100, height=30)

        # Skip Button
        self.button_next = tk.Button(self.master, text=">>", command=self.skip)
        self.button_next.place(x=370, y=300, width=30, height=30)

        # Previous Button
        self.previous_button = tk.Button(self.master, text="<<", command=self.previous)
        self.previous_button.place(x=300, y=300, width=30, height=30)

        # Bind the function to close the window to the closing event
        self.master.protocol("WM_DELETE_WINDOW", self.on_closing)

    def play(self):
        if self.paused:
            pygame.mixer.music.unpause()
            self.paused = False
        else:
            if self.song_list:
                pygame.mixer.music.load(self.song_list[self.current_song_index])
                pygame.mixer.music.play()
                self.update_song_label()

    def pause(self):
        if pygame.mixer.music.get_busy():
            pygame.mixer.music.pause()
            self.paused = True

    def skip(self):
        if self.song_list:
            self.current_song_index = (self.current_song_index + 1) % len(self.song_list)
            pygame.mixer.music.load(self.song_list[self.current_song_index])
            pygame.mixer.music.play()
            self.update_song_label()

    def previous(self):
        if self.song_list:
            self.current_song_index = (self.current_song_index - 1) % len(self.song_list)
            pygame.mixer.music.load(self.song_list[self.current_song_index])
            pygame.mixer.music.play()
            self.update_song_label()

    # Function to handle the window closing event
    def on_closing(self):
        pygame.mixer.music.stop()
        self.master.destroy()

    # Function to update the song label
    def update_song_label(self):
        if self.song_list:
            song_name = os.path.basename(self.song_list[self.current_song_index])
            self.song_label.config(text=song_name)

def main():
    pygame.init()
    root = tk.Tk()
    app = MusicPlayer(root)
    root.mainloop()

main()
