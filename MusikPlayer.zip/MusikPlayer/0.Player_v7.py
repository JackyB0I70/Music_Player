import os
import random
import tkinter as tk
from tkinter import ttk
import pygame
from tkinter import filedialog

class MusicPlayer:
    def __init__(self, master):
        self.master = master
        self.master.title("Music Player")
        self.master.geometry("700x550")
        self.master.configure(bg='black')
        self.master.iconbitmap("0.Logo.ico")
        
        self.current_song_index = 0
        self.paused = False

        self.song_list = []
        self.load_songs()

        self.create_widgets()

    def load_songs(self):
        folder_path = os.path.join(os.path.expanduser("~"), "Documents", "Python", "MusikPlayer")
        self.song_list = [os.path.join(folder_path, f) for f in os.listdir(folder_path) if f.endswith('.mp3')]
        random.shuffle(self.song_list)

    def create_widgets(self):
        # Song Label
        self.label_title = tk.Label(self.master, bg="black", fg='#FF0000', font="bold 25", text="MUSIK PLAYER")
        self.label_title.place(x=100, y=50, width=500, height=30)
        
        self.song_label = tk.Label(self.master, bg="black", fg='blue', font="bold 15", text="")
        self.song_label.place(x=100, y=100, width=500, height=30)

        # Timer Label
        self.timer_label = tk.Label(self.master, bg="black", fg='white', font="bold 15", text="")
        self.timer_label.place(x=100, y=150, width=100, height=30)

        # Play Button
        self.button_play = tk.Button(self.master, text="PLAY", command=self.play)
        self.button_play.place(x=300, y=200, width=100, height=30)

        # Pause Button
        self.button_pause = tk.Button(self.master, text="PAUSE", command=self.pause)
        self.button_pause.place(x=300, y=250, width=100, height=30)

        # Skip Button
        self.button_next = tk.Button(self.master, text=">>", command=self.skip)
        self.button_next.place(x=370, y=300, width=30, height=30)

        # Previous Button
        self.previous_button = tk.Button(self.master, text="<<", command=self.previous)
        self.previous_button.place(x=300, y=300, width=30, height=30)

        # Bind the function to close the window to the closing event
        self.master.protocol("WM_DELETE_WINDOW", self.on_closing)

    def play(self):
        if self.paused:
            pygame.mixer.music.unpause()
            self.paused = False
        else:
            if self.song_list:
                pygame.mixer.music.load(self.song_list[self.current_song_index])
                pygame.mixer.music.play()
                self.update_song_label()
                self.update_timer_label()

    def pause(self):
        if pygame.mixer.music.get_busy():
            pygame.mixer.music.pause()
            self.paused = True

    def skip(self):
        if self.song_list:
            self.current_song_index = (self.current_song_index + 1) % len(self.song_list)
            pygame.mixer.music.load(self.song_list[self.current_song_index])
            pygame.mixer.music.play()
            self.update_song_label()
            self.update_timer_label()

    def previous(self):
        if self.song_list:
            self.current_song_index = (self.current_song_index - 1) % len(self.song_list)
            pygame.mixer.music.load(self.song_list[self.current_song_index])
            pygame.mixer.music.play()
            self.update_song_label()
            self.update_timer_label()

    def on_closing(self):
        pygame.mixer.music.stop()
        self.master.destroy()

    def update_song_label(self):
        if self.song_list:
            song_name = os.path.basename(self.song_list[self.current_song_index])
            song_name = song_name.split(".mp3")[0]
            song_name_parts = song_name.split("_")
            reordered_song_name = song_name_parts[1] + ", " + song_name_parts[0]
            self.song_label.config(text=reordered_song_name)

    def update_timer_label(self):
        if pygame.mixer.music.get_busy():
            current_pos_ms = pygame.mixer.music.get_pos()
            current_pos_sec = current_pos_ms // 1000
            current_minutes = current_pos_sec // 60
            current_seconds = current_pos_sec % 60

            song_length_ms = pygame.mixer.Sound(self.song_list[self.current_song_index]).get_length() * 1000
            song_length_sec = song_length_ms // 1000
            song_minutes = song_length_sec // 60
            song_seconds = song_length_sec % 60

            current_time_str = f"{current_minutes:02d}:{current_seconds:02d}"
            song_duration_str = f"{song_minutes:02d}:{song_seconds:02d}"

            self.timer_label.config(text=f"{current_time_str} / {song_duration_str}")

def main():
    pygame.init()
    root = tk.Tk()
    app = MusicPlayer(root)

    def update_timer():
        app.update_timer_label()
        root.after(100, update_timer)

    update_timer()

    root.mainloop()

main()

